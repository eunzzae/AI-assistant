from assistant import Assistant

instance = Assistant('이름', weather_api_key='키')
instance.start()